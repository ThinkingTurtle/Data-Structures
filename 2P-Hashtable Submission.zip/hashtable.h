/*
 * hashtable.h
 *
 * A basic hashtable implementation.  This hashtable uses vectors,
 * rather than linked lists, to implement chaining.
 * 
 * Author: <your name here>
 */

#ifndef _HASHTABLE_PROJECT_H
#define _HASHTABLE_PROJECT_H

#include <functional>   // for std::hash
#include <vector>
#include <iostream>
using namespace std;

template <class T, class H = std::hash<T>>
class hashtable {
public:
    // constructor
    hashtable(){
        filled = 0;
        loadfactor = 0.75;
        vec.resize(4);
    };

    // basic hashset operations
    void insert(const T& key){
        if (contains(key)){ return; }
        vec[hash(key)%vec.size()].push_back(key);
        filled++;
        if ( double(filled)/vec.size() > loadfactor){
            T to_hash;
            filled = 0;
            vector<vector<T>> old_vec;
            old_vec.swap(vec);
            vec.resize(old_vec.size()*2);
            for(int i = 0; i<old_vec.size(); i++){
                if(old_vec[i].size() != 0){
                    for(int j = 0; j<old_vec[i].size(); j++){
                        to_hash = old_vec[i][j];
                        insert(to_hash);
                    }
                }
            }
        }
    };
    void remove(const T& key){
        for(int i = 0 ; i < vec[hash(key)%vec.size()].size(); i++){
            if (vec[hash(key)%vec.size()][i] == key){
                vec[hash(key)%vec.size()].erase(vec[hash(key)%vec.size()].begin()+i);
                filled--;
            }
        }
    };
    bool contains(const T& key){
        for(int i = 0 ; i < vec[hash(key)%vec.size()].size(); i++){
            if (vec[hash(key)%vec.size()][i] == key){
                return(true);
            }
        }
        return(false);
    };
    size_t size(){
        return(filled);
    };

    // diagnostic functions
    double load_factor(){
        return(loadfactor);
    };

    // convenience method, invokes the "hash" template parameter
    // function object to get a hash code
    static size_t hash(const T &key) {
        H h;
        return h(key);
    }

private:
    vector<vector<T>> vec;
    size_t filled;
    double loadfactor;
 
};

#endif
