#ifndef _TRIE_NODE_H
#define _TRIE_NODE_H

#include <string>
#include <vector>

using namespace std;

class tnode {
public:
    tnode(){
        endofword = false;
        vecofnodes = new tnode*[26];
        for(size_t i = 0; i<26; i++){
            vecofnodes[i]=nullptr;
        }
    };
    void endofwordsetter(bool t){
        endofword = t;
    };
    bool endofwordgetter(){
        return(endofword);
    };
    tnode* getnode(int pos){
        return(vecofnodes[pos]);
    };
    void insertnode(int pos){
        vecofnodes[pos] = new tnode;
    };
    ~tnode(){
        for (int i = 0; i<26; i++){
            if (vecofnodes[i] != nullptr){
                delete vecofnodes[i];
            }
        }
        delete[] vecofnodes;
    };
private:
    tnode** vecofnodes;
    bool endofword;
};

#endif