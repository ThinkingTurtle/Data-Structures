/*
 * trie.cpp
 *
 * Method definitions for the trie class.
 *
 * Author: <Aarnav Singh>
 */

#include "trie.h"


void trie::insert(const string &s){
    tnode* currnode = root;
    int letternum;
    for(size_t i = 0; i<s.size(); i++){
        letternum = s[i]-'a';
        if (currnode->getnode(letternum) == nullptr){
            currnode->insertnode(letternum);
        }
        currnode = currnode->getnode(letternum);
    }
    currnode->endofwordsetter(true);
}

bool trie::contains(const string &s){
    tnode* currnode = root;
    for(size_t i = 0; i<s.size(); i++){
        currnode = currnode->getnode(s[i]-'a');
        if (currnode == nullptr){
            return(false);
        }
    }
    return(currnode->endofwordgetter());
}
bool trie::is_prefix(const string &s){
    tnode* currnode = root;
    for(size_t i = 0; i<s.size(); i++){
        currnode = currnode->getnode(s[i]-'a');
        if (currnode == nullptr){
            return(false);
        }
    }
    return(true);
}
void trie::extend(const string &prefix, vector<string> &result){
    tnode* currnode = root;
    for(size_t i=0; i<prefix.size(); i++){
        currnode = currnode->getnode(prefix[i]-'a');
        if (currnode == nullptr){
            return;
        }
    }
    rextend(prefix,currnode,result);
}
void trie::rextend(string prefix, tnode* currnode, vector<string> &result){
    if (currnode->endofwordgetter()){
        result.push_back(prefix);
    }
    for(int i=0; i<26; i++){
        if (currnode->getnode(i) != nullptr){
            rextend( prefix + char('a'+i) , currnode->getnode(i), result);
        }
    }
}
