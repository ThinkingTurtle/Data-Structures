/*
 * stack-stage3.h
 *
 * Implements a simple stack class using dynamic arrays.
 * This may be implemented in 3 stages:
 *   Stage 1: non-template stack class storing strings,
 *            unsafe copies/assignments
 *   Stage 2: template stack class, unsafe copies/assignments
 *   Stage 3: template stack class, safe copies/assignments
 *
 * Note: no underflow detection is performed.  Performing pop() or top()
 * on an empty stack results in undefined behavior (possibly crashing your
 * program)!
 *
 * Author: Your Name
 */

#ifndef _STACK_H
#define _STACK_H

#include <cstddef> // for size_t

using namespace std;
template<typename T>
class stack {
  public:
    T top(){return _data[stack_size-1];}; 

    void push(const T &to_add) { 
      if (stack_size == stack_capacity){
        T* new_stack = new T [stack_capacity*2];
          for(int i=0; i<stack_size; i++){
            new_stack[i]=_data[i];
          }
          delete[]_data;
          _data=new_stack;
          stack_capacity = stack_capacity*2;
        }
      _data[stack_size]=to_add;
      stack_size++;
      return; 
      }

    void pop() {
      stack_size--;
      }

    size_t size() { return stack_size; }

    bool is_empty() { 
        if (stack_size==0){
          return true;
        }
      return false; 
      }

    stack() { 
      stack_size = 0; 
      stack_capacity = 1; 
    }
    
    stack(const stack& to_copy){
        stack_size = to_copy.stack_size;
        stack_capacity = to_copy.stack_capacity;
        _data = new T[stack_capacity];
        for(int i=0; i<stack_size; i++){
            _data[i] = to_copy._data[i];
        }
    }
    
    stack& operator=(const stack& to_copy){
        if(this == &to_copy) { 
            return *this; 
        }
        stack_size = to_copy.stack_size;
        stack_capacity = to_copy.stack_capacity;
        delete[] _data; 
        _data = new T[stack_capacity];
        for(int i=0; i<stack_size; i++){
            _data[i] = to_copy._data[i];
        }
        return *this;
    }

    ~stack(){
        delete[] _data;
    }

  private:
    T* _data = new T[1];
    int stack_size;
    int stack_capacity;
};


#endif